char background[60] = "image//Background//Transparent Background.bmp";




